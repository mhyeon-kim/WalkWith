package model.service;

public class ReservationNotFoundException extends Exception {
    private static final long serialVersionUID = 1L;

    public ReservationNotFoundException() {
        super();
    }

    public ReservationNotFoundException(String arg0) {
        super(arg0);
    }
}