package model.service;

public class ExistingPetException extends Exception {
    private static final long serialVersionUID = 1L;

    public ExistingPetException() {
        super();
    }

    public ExistingPetException(String arg0) {
        super(arg0);
    }
}